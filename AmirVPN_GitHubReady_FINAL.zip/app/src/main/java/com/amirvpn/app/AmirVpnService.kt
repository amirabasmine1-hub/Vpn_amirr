package com.amirvpn.app

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import kotlin.concurrent.thread

class AmirVpnService : VpnService() {

    private var vpnInterface: ParcelFileDescriptor? = null
    private var worker: Thread? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (vpnInterface == null) {
            startLocalVpn()
        }
        return START_STICKY
    }

    private fun startLocalVpn() {
        vpnInterface = Builder()
            .setSession("Amir VPN")
            .setMtu(1500)
            .addAddress("10.8.0.2", 32)
            .addRoute("0.0.0.0", 0)
            .addDnsServer("1.1.1.1")
            .establish()

        isRunning = vpnInterface != null

        worker = thread(start = true, name = "AmirVPN-Tunnel") {
            runTunnelLoop()
        }
    }

    private fun runTunnelLoop() {
        val fd = vpnInterface?.fileDescriptor ?: return

        FileInputStream(fd).use { input ->
            FileOutputStream(fd).use { output ->
                val buffer = ByteArray(32767)

                while (!Thread.currentThread().isInterrupted && isRunning) {
                    try {
                        val length = input.read(buffer)
                        if (length <= 0) break

                        /*
                         * Version 1.0 creates the Android VPN interface.
                         * A real Internet VPN needs a remote tunnel protocol
                         * (for example WireGuard) and a remote VPN server.
                         *
                         * We intentionally do not pretend that simply
                         * creating this interface provides encrypted Internet
                         * access.
                         */
                    } catch (_: Exception) {
                        break
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        isRunning = false
        worker?.interrupt()
        worker = null

        try {
            vpnInterface?.close()
        } catch (_: Exception) {
        }

        vpnInterface = null
        super.onDestroy()
    }

    companion object {
        @Volatile
        var isRunning: Boolean = false
    }
}
