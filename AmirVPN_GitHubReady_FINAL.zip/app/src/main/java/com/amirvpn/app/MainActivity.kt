package com.amirvpn.app

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var button: Button
    private lateinit var status: TextView
    private lateinit var info: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        button = findViewById(R.id.connectButton)
        status = findViewById(R.id.statusText)
        info = findViewById(R.id.infoText)

        button.setOnClickListener {
            if (AmirVpnService.isRunning) {
                stopService(Intent(this, AmirVpnService::class.java))
                updateUi(false)
            } else {
                val prepareIntent = VpnService.prepare(this)
                if (prepareIntent != null) {
                    startActivityForResult(prepareIntent, REQUEST_VPN)
                } else {
                    startVpn()
                }
            }
        }
    }

    private fun startVpn() {
        startService(Intent(this, AmirVpnService::class.java))
        updateUi(true)
    }

    private fun updateUi(connected: Boolean) {
        if (connected) {
            status.text = "Connected"
            status.setTextColor(0xFF35D07F.toInt())
            button.text = "DISCONNECT"
            info.text = "Local VPN tunnel is active"
        } else {
            status.text = "Disconnected"
            status.setTextColor(0xFFFF6B6B.toInt())
            button.text = "CONNECT"
            info.text = "VPN service is ready"
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_VPN && resultCode == RESULT_OK) {
            startVpn()
        }
    }

    companion object {
        private const val REQUEST_VPN = 1001
    }
}
