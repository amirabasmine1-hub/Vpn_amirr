# Amir VPN 1.0

Android VPNService starter project with a GitHub Actions workflow.

## Build APK on GitHub
1. Push/upload the project files to the repository.
2. Open **Actions**.
3. Select **Build Amir VPN APK**.
4. Run the workflow with **Run workflow** (or push to `main`).
5. Open the completed run and download the **AmirVPN-debug** artifact.
6. Inside the downloaded artifact is `app-debug.apk`.

The workflow uses JDK 17 and Gradle 8.9 directly, so the repository does not need a Gradle Wrapper.

## Important
This app creates an Android VPN interface but does not yet connect to a remote VPN server or provide a complete Internet VPN tunnel.
